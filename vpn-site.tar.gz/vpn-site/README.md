# OpenLink site

## Before pushing

1. Edit `index.html` — replace `YOUR-EMAIL@protonmail.com` with your real signup email.
2. Pick a real project name — search/replace `OpenLink` across all files.

## Preview locally

```bash
docker run --rm -it -v "$PWD:/srv/jekyll" -p 4000:4000 \
  jekyll/jekyll jekyll serve --watch --force_polling
```

Open http://localhost:4000.

## Deploy

Push to `main`. GitHub Pages builds automatically.
